// Narrative content for 03:17. All memories remain suggestive and non-graphic.
export const clues = [
  {
    id: 'warning',
    title: 'Um papel dobrado',
    room: 'Cozinha',
    text: 'Dentro da gaveta, entre talheres e contas antigas, há um pequeno pedaço de papel.\n\n“Não conte para ninguém.”\n\nNão existe assinatura.',
    reflection: 'Clara reconhece a letra. Não quer lembrar de onde.',
  },
  {
    id: 'alone',
    title: 'Atrás do porta-retrato',
    room: 'Sala',
    text: 'A fotografia da família está virada para baixo. Atrás dela, uma frase escrita a lápis:\n\n“Ele sabe quando você está sozinha.”\n\nNo andar de cima, uma tábua range.',
    reflection: 'A casa está quieta demais. A porta da frente acabou de se fechar.',
  },
  {
    id: 'drawing',
    title: 'O desenho da porta',
    room: 'Quarto de Clara',
    text: 'Entre desenhos da infância, a mesma figura masculina aparece várias vezes. Neste, Clara está de um lado de uma porta. O homem está do outro.\n\nAbaixo, com letras pequenas:\n\n“Ele disse que era segredo.”',
    reflection: 'Ela lembra de esperar os passos se afastarem. Lembra de ficar em silêncio.',
  },
  {
    id: 'messages',
    title: 'O celular antigo',
    room: 'Escritório',
    text: 'Quase todas as conversas foram apagadas. Algumas mensagens ainda estão aqui.\n\n“Você precisa contar para alguém.”\n“Eu sei que você está com medo.”\n“Ele não pode continuar fazendo isso.”\n\nMais abaixo, uma mensagem antiga:\n\n“Clara, aquilo que aconteceu não foi culpa sua.”',
    reflection: 'A tela se apaga. As palavras permanecem. Ela precisa encontrar a mãe.',
  },
  {
    id: 'photo',
    title: 'Três pessoas',
    room: 'Depósito no andar de cima',
    text: 'Uma fotografia esquecida entre caixas. Clara, ainda pequena. Sua mãe. E o homem que percorre os corredores.\n\nSeu padrasto.\n\nO rosto é o mesmo. A voz também.',
    reflection: 'Não é a primeira madrugada em que ela tem medo dentro da própria casa.',
  },
  {
    id: 'key',
    title: 'A chave da porta',
    room: 'Escritório',
    text: 'Sob um envelope, a chave da entrada. O metal está frio na mão de Clara.\n\nEla guarda a chave e respira devagar. Desta vez, existe um caminho para fora.',
    reflection: 'A saída está no térreo. Antes, ela precisa tentar falar com a mãe.',
  },
  {
    id: 'mother',
    title: 'Você nunca percebeu?',
    room: 'Quarto da mãe',
    text: '— Mãe…\n\nSua voz quase não sai.\n\n— Clara, o que aconteceu?\n\nEla olha para a mãe.\n\n— Você nunca percebeu?\n\nNo corredor, uma figura para atrás da porta. A luz se apaga.\n\n— Você prometeu que não contaria.',
    reflection: 'Clara aperta a chave. O objetivo agora é sair da casa.',
  },
];

export const chapterTitles = [
  'I · O barulho na cozinha',
  'II · Alguém está aqui',
  'III · O que a casa guarda',
  'IV · Não foi culpa sua',
  'V · Do outro lado da porta',
];

export const endText = {
  tell: {
    title: 'CONTAR',
    text: 'Clara atravessa a porta. Ainda está com medo, mas caminha até a casa de uma pessoa adulta em quem confia.\n\nQuando a porta se abre, ela diz:\n\n“Eu preciso de ajuda.”\n\nA madrugada não apaga o que aconteceu. Pela primeira vez, ela não precisa carregar tudo sozinha.',
  },
  silence: {
    title: 'AINDA NÃO',
    text: 'As palavras ainda não saem. Clara não consegue contar nesta noite.\n\nO medo pode tornar difícil pedir ajuda. O silêncio não significa consentimento e não torna Clara responsável pelo que sofreu.\n\nEsta não precisa ser a última página da sua história. Ainda é possível procurar alguém de confiança.',
  },
  closing: 'Alguns segredos não protegem ninguém. Eles protegem quem está fazendo mal.',
};

export const helpInfo = {
  title: 'Você não precisa passar por isso sem apoio.',
  intro: 'Esta é uma história fictícia sobre medo, violência familiar e a possibilidade de pedir ajuda. A responsabilidade é sempre de quem causa o mal.',
  steps: [
    'Procure uma pessoa adulta de confiança: alguém da família, uma professora, um professor, uma pessoa da equipe de saúde ou outro adulto que possa ajudar a proteger você.',
    'Você pode começar com uma frase simples: “Não me sinto em segurança e preciso conversar.” Se falar for difícil, escrever uma mensagem também pode ajudar.',
    'Se a primeira pessoa não escutar, procure outra. Você merece ser levado a sério e receber apoio, mesmo que ainda não consiga explicar tudo.',
    'Busque os serviços de proteção à criança e ao adolescente e de atendimento a vítimas de violência da sua região. Use um dispositivo seguro se alguém acompanha suas mensagens.',
  ],
  immediateDanger: 'Se houver perigo imediato, procure um local seguro e acione o serviço de emergência da sua região quando puder fazer isso com segurança.',
};
