# 03:17 — O que a casa guarda

Jogo narrativo 3D em primeira pessoa, em português. Casa de dois andares em escala métrica, cenário e mobiliário volumétricos, escada real navegável, câmera livre, colisões, lanterna com sombras, perseguição, esconderijos, diário, sete pistas e dois finais.

## Executar

Requer Node.js. Na pasta do projeto, execute `node server.mjs` e abra http://127.0.0.1:4317/ . Não abra index.html diretamente com file://: módulos JavaScript precisam de servidor HTTP. A biblioteca Three.js está incluída localmente; não precisa instalar dependências para jogar. Fontes online têm fallback local.

## Controles

WASD: caminhar. Mouse: olhar horizontal/vertical. Shift: correr. C: agachar. F: luz do celular. E: examinar, usar interruptor, entrar/sair de esconderijo. M: mapa expansível com seleção de andar. J: diário. Esc: pausa. Em telas sensíveis ao toque, use botões direcionais e arraste a cena.

No menu de pausa há luminosidade, volume, sensibilidade e modo narrativa sem captura. A luz facilita a visão do perseguidor; correr pode atrair sua atenção. Agachar e apagar a luz reduzem a detecção. Em um armário, E sai do esconderijo. A partida é mantida na memória da aba, sem gravação persistente.

## Percurso

Quarto de Clara (gaveta) → cozinha (bilhete) → escritório térreo (desenho) → quarto antigo superior (celular) → depósito (foto) → sala de leitura superior (chave) → quarto da mãe → porta da frente. A escada central sobe na direção da frente da casa; no piso superior, circule pelos quartos para alcançar os fundos.

## Arquivos

- `dist/world.js`: cenário, móveis, personagens, medidas e colisores.
- `dist/game.js`: câmera, navegação, IA, progressão e interface.
- `dist/audio.js`: efeitos sonoros Web Audio e voz pt-BR quando disponível.
- `dist/story.js`: narrativa.
- `dist/assets/`: fotografia e desenho fictícios criados com ImageGen; os demais objetos são geometria 3D.

Esta primeira versão usa modelos procedurais, materiais e iluminação em tempo real. Não usa fotogrametria nem pretende ser uma produção AAA. Não há cenas explícitas de abuso. As informações de apoio no final incluem referências oficiais brasileiras.

## Verificação

`node --check dist/game.js`, `node --check dist/world.js`, `node --check dist/audio.js`. O roteiro `qa.mjs` registra erros do navegador, verifica o mapa, percorre a escada com teclas reais, testa acesso às pistas e ambos os finais. A automação usa Playwright do ambiente de desenvolvimento e não é necessária para jogar.

Three.js r180, licença MIT em `dist/vendor/LICENSE-THREE.txt`.
