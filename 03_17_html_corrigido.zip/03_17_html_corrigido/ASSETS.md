# Imagens narrativas

Criadas com a ferramenta ImageGen integrada, não com API/CLI. Personagens inteiramente fictícios. Arquivos: `dist/assets/family.png` e `dist/assets/drawing.png`.

Prompt final — fotografia:
Use case: photorealistic-natural. Flat photographic texture for a framed photograph object in a 3D psychological game titled 03:17. Natural ordinary family cellphone photograph taken in 2018 in a modest Brazilian living room. Exactly three fictional fully clothed people: Clara, 16, brown hair; mother around 40; male stepfather around 45 wearing dark shirt. Restrained natural expressions, typical family-photo pose. Horizontal 3:2, 1536×1024. No print borders or frame. Warm indoor light, imperfect casual exposure, subtle faded colors and slight wear. Completely nonsexual, no violence, no explicit horror, no additional people, text, logos or watermark.

Prompt final — desenho:
Use case: illustration-story. Flat scanned paper drawing texture for a paper object in a 3D psychological game titled 03:17. Innocent symbolic child's drawing with colored pencil and wax crayon on ivory paper. One young girl on left of a closed central door, one tall fully clothed adult male on right. Simple uneven childlike lines. Portrait 2:3, 1024×1536. Exact sentence below: "Ele disse que era segredo." Clearly legible natural pencil handwriting, once, no other lettering. Paper grain, subtle pencil marks. No violence, sexual content, monsters, frame, table or watermark.
