#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
printf '%s\n' 'Abra http://127.0.0.1:4317/ no navegador.'
node server.mjs
