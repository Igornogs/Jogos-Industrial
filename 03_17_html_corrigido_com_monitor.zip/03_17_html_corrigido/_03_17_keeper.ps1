param(
    [Parameter(Mandatory=$true)][string]$ProjectDir,
    [string]$GameUrl = 'http://127.0.0.1:4317/'
)

$ErrorActionPreference = 'SilentlyContinue'

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class KeeperHotKey {
    [StructLayout(LayoutKind.Sequential)]
    public struct MSG {
        public IntPtr hwnd;
        public uint message;
        public UIntPtr wParam;
        public IntPtr lParam;
        public uint time;
        public int pt_x;
        public int pt_y;
    }

    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll")]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll")]
    public static extern bool PeekMessage(out MSG msg, IntPtr hWnd, uint min, uint max, uint remove);
}
'@

$WM_HOTKEY = 0x0312
$PM_REMOVE = 0x0001
$MOD_CONTROL = 0x0002
$VK_OEM_PERIOD = 0xBE
$HOTKEY_ID = 317

$registered = [KeeperHotKey]::RegisterHotKey([IntPtr]::Zero, $HOTKEY_ID, $MOD_CONTROL, $VK_OEM_PERIOD)
if (-not $registered) {
    Write-Host 'AVISO: nao foi possivel registrar CTRL + . globalmente.' -ForegroundColor Yellow
    Write-Host 'Nesse caso, feche esta janela do terminal para encerrar.' -ForegroundColor Yellow
}

$edge = Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
if (-not (Test-Path $edge)) {
    $edge = Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'
}

$chrome = Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'
if (-not (Test-Path $chrome)) {
    $chrome = Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'
}

if (Test-Path $edge) {
    $browser = $edge
    $browserName = 'msedge.exe'
} elseif (Test-Path $chrome) {
    $browser = $chrome
    $browserName = 'chrome.exe'
} else {
    Write-Host 'ERRO: Microsoft Edge ou Google Chrome nao encontrado.' -ForegroundColor Red
    Start-Sleep -Seconds 4
    exit 2
}

$profileDir = Join-Path $env:TEMP '03_17_dedicated_browser_profile'
New-Item -ItemType Directory -Force -Path $profileDir | Out-Null

$server = $null
$serverFile = Join-Path $ProjectDir 'server.mjs'
if (Test-Path $serverFile) {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($node) {
        $server = Start-Process -FilePath $node.Source -ArgumentList 'server.mjs' -WorkingDirectory $ProjectDir -WindowStyle Hidden -PassThru
        Start-Sleep -Milliseconds 1200
    } else {
        Write-Host 'AVISO: Node.js nao encontrado. O servidor precisa ja estar rodando.' -ForegroundColor Yellow
    }
}

function Get-GameBrowserProcesses {
    $needle = [Regex]::Escape($profileDir)
    @(
        Get-CimInstance Win32_Process -Filter "Name='$browserName'" |
        Where-Object { $_.CommandLine -match $needle }
    )
}

function Start-GameWindow {
    $args = @(
        "--user-data-dir=$profileDir",
        "--app=$GameUrl",
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-session-crashed-bubble',
        '--start-maximized'
    )

    Start-Process -FilePath $browser -ArgumentList $args | Out-Null
    Start-Sleep -Milliseconds 900
}

function Stop-GameWindow {
    Get-GameBrowserProcesses | ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

try {
    Start-GameWindow
    Write-Host '03:17 aberto.' -ForegroundColor Cyan
    Write-Host 'Se a janela fechar, ela sera reaberta automaticamente.' -ForegroundColor Cyan
    Write-Host 'Pressione CTRL + . para encerrar.' -ForegroundColor Green

    $running = $true
    while ($running) {
        if ($registered) {
            $msg = New-Object KeeperHotKey+MSG
            while ([KeeperHotKey]::PeekMessage([ref]$msg, [IntPtr]::Zero, 0, 0, $PM_REMOVE)) {
                if ($msg.message -eq $WM_HOTKEY -and $msg.wParam.ToUInt32() -eq $HOTKEY_ID) {
                    $running = $false
                    break
                }
            }
        }

        if (-not $running) { break }

        $gameProcs = Get-GameBrowserProcesses
        if ($gameProcs.Count -eq 0) {
            Write-Host 'A janela foi fechada. Reabrindo...' -ForegroundColor Yellow
            Start-GameWindow
        }

        Start-Sleep -Milliseconds 300
    }
}
finally {
    if ($registered) {
        [KeeperHotKey]::UnregisterHotKey([IntPtr]::Zero, $HOTKEY_ID) | Out-Null
    }

    Stop-GameWindow

    if ($server -and -not $server.HasExited) {
        Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
    }

    Start-Sleep -Milliseconds 250
    Remove-Item -Recurse -Force $profileDir -ErrorAction SilentlyContinue
}
