@echo off
setlocal
cd /d "%~dp0"
title 03:17 - Monitor ^| CTRL + . para sair
color 0C

echo.
echo ==========================================================
echo   03:17 - MODO JOGO
echo ==========================================================
echo.
echo A janela do jogo sera reaberta automaticamente se fechar.
echo Para encerrar de verdade, pressione CTRL + .
echo.
echo Nao feche esta janela do terminal.
echo ==========================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_03_17_keeper.ps1" -ProjectDir "%~dp0" -GameUrl "http://127.0.0.1:4317/"
set "CODE=%ERRORLEVEL%"

echo.
if "%CODE%"=="0" (
  echo 03:17 encerrado.
) else (
  echo O monitor terminou com codigo %CODE%.
)
timeout /t 2 /nobreak >nul
exit /b %CODE%
